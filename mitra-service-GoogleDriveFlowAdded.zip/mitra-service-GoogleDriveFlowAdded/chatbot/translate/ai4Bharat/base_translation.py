import os
import requests


ai4bharat_api_key = os.getenv("BHASHANI_API_KEY")
ai4bharat_user_id = os.getenv("BHASHANI_USER_ID")
ai4bharat_pipeline_id = os.getenv("BHASHANI_PIPELINE_ID")


def get_ulca_pipeline_models(task_type, source_language=None, target_language=None):
    url = "https://meity-auth.ulcacontrib.org/ulca/apis/v0/model/getModelsPipeline"

    payload = {
        "pipelineTasks": [
            {"taskType": task_type},
        ],
        "pipelineRequestConfig": {
            "pipelineId": ai4bharat_pipeline_id
        }
    }

    headers = {
        'userID': ai4bharat_user_id,
        'ulcaApiKey': ai4bharat_api_key,
        'Content-Type': 'application/json'
    }
    print("payload: ", payload)
    try:
        response = requests.post(url, headers=headers, json=payload, timeout=10)
        print("response: ", response.text)
        response.raise_for_status()

        data = response.json()
        service_id = None

        configs = data.get("pipelineResponseConfig", [])
        for task in configs:
            if task.get("taskType") == task_type:
                for cfg in task.get("config", []):
                    lang_cfg = cfg.get("language", {})
                    src = lang_cfg.get("sourceLanguage")
                    tgt = lang_cfg.get("targetLanguage")

                    if source_language == src and (target_language is None or target_language == tgt):
                        service_id = cfg.get("serviceId")
                        break
                if service_id:
                    break
        api_key = data.get("pipelineInferenceAPIEndPoint", {}).get("inferenceApiKey", {}).get("value")

        return {
            'success': True,
            'service_id': service_id,
            'inference_api_key': api_key,
            'raw_data': data
        }
    except requests.exceptions.RequestException as e:
        print("Get model pipeline error: ", e)
        return {
            'success': False,
            'error': str(e),
            'service_id': None,
            'inference_api_key': None,
            'raw_data': None
        }


def get_service_id(task_type, source_language=None, target_language=None):
    service_id=None

    model_pipeline = {
        "languages": [
            {
                "sourceLanguage": "bn",
                "targetLanguageList": [
                    "en",
                    "as",
                    "brx",
                    "gu",
                    "hi",
                    "kn",
                    "ml",
                    "mni",
                    "mr",
                    "or",
                    "pa",
                    "ta",
                    "te"
                ]
            },
            {
                "sourceLanguage": "en",
                "targetLanguageList": [
                    "as",
                    "bn",
                    "brx",
                    "gu",
                    "hi",
                    "kn",
                    "ml",
                    "mni",
                    "mr",
                    "or",
                    "pa",
                    "ta",
                    "te"
                ]
            },
            {
                "sourceLanguage": "gu",
                "targetLanguageList": [
                    "en",
                    "as",
                    "bn",
                    "brx",
                    "hi",
                    "kn",
                    "ml",
                    "mni",
                    "mr",
                    "or",
                    "pa",
                    "ta",
                    "te"
                ]
            },
            {
                "sourceLanguage": "hi",
                "targetLanguageList": [
                    "en",
                    "as",
                    "bn",
                    "brx",
                    "gu",
                    "kn",
                    "ml",
                    "mni",
                    "mr",
                    "or",
                    "pa",
                    "ta",
                    "te"
                ]
            },
            {
                "sourceLanguage": "kn",
                "targetLanguageList": [
                    "en",
                    "as",
                    "bn",
                    "brx",
                    "gu",
                    "hi",
                    "ml",
                    "mni",
                    "mr",
                    "or",
                    "pa",
                    "ta",
                    "te"
                ]
            },
            {
                "sourceLanguage": "ml",
                "targetLanguageList": [
                    "en",
                    "as",
                    "bn",
                    "brx",
                    "gu",
                    "hi",
                    "kn",
                    "mni",
                    "mr",
                    "or",
                    "pa",
                    "ta",
                    "te"
                ]
            },
            {
                "sourceLanguage": "mr",
                "targetLanguageList": [
                    "en",
                    "as",
                    "bn",
                    "brx",
                    "gu",
                    "hi",
                    "kn",
                    "ml",
                    "mni",
                    "or",
                    "pa",
                    "ta",
                    "te"
                ]
            },
            {
                "sourceLanguage": "or",
                "targetLanguageList": [
                    "en",
                    "as",
                    "bn",
                    "brx",
                    "gu",
                    "hi",
                    "kn",
                    "ml",
                    "mni",
                    "mr",
                    "pa",
                    "ta",
                    "te"
                ]
            },
            {
                "sourceLanguage": "pa",
                "targetLanguageList": [
                    "en",
                    "as",
                    "bn",
                    "brx",
                    "gu",
                    "hi",
                    "kn",
                    "ml",
                    "mni",
                    "mr",
                    "or",
                    "ta",
                    "te"
                ]
            },
            {
                "sourceLanguage": "sa",
                "targetLanguageList": [
                    "en",
                    "as",
                    "bn",
                    "brx",
                    "gu",
                    "hi",
                    "kn",
                    "ml",
                    "mni",
                    "mr",
                    "or",
                    "pa",
                    "ta",
                    "te"
                ]
            },
            {
                "sourceLanguage": "ta",
                "targetLanguageList": [
                    "en",
                    "as",
                    "bn",
                    "brx",
                    "gu",
                    "hi",
                    "kn",
                    "ml",
                    "mni",
                    "mr",
                    "or",
                    "pa",
                    "te"
                ]
            },
            {
                "sourceLanguage": "te",
                "targetLanguageList": [
                    "en",
                    "as",
                    "bn",
                    "brx",
                    "gu",
                    "hi",
                    "kn",
                    "ml",
                    "mni",
                    "mr",
                    "or",
                    "pa",
                    "ta"
                ]
            },
            {
                "sourceLanguage": "ur",
                "targetLanguageList": [
                    "en",
                    "as",
                    "bn",
                    "brx",
                    "gu",
                    "hi",
                    "kn",
                    "ml",
                    "mni",
                    "mr",
                    "or",
                    "pa",
                    "ta",
                    "te"
                ]
            }
        ],
        "pipelineResponseConfig": [
            {
                "taskType": "asr",
                "config": [
                    {
                        "serviceId": "ai4bharat/conformer-multilingual-indo_aryan-gpu--t4",
                        "modelId": "6411746956e9de23f65b5426",
                        "language": {
                            "sourceLanguage": "bn",
                            "sourceScriptCode": "Beng"
                        },
                        "domain": [
                            "general"
                        ]
                    },
                    {
                        "serviceId": "ai4bharat/whisper-medium-en--gpu--t4",
                        "modelId": "641c0be440abd176d64c3f92",
                        "language": {
                            "sourceLanguage": "en",
                            "sourceScriptCode": "Latn"
                        },
                        "domain": [
                            "general"
                        ]
                    },
                    {
                        "serviceId": "ai4bharat/conformer-multilingual-indo_aryan-gpu--t4",
                        "modelId": "6411746056e9de23f65b5425",
                        "language": {
                            "sourceLanguage": "gu",
                            "sourceScriptCode": "Gujr"
                        },
                        "domain": [
                            "general"
                        ]
                    },
                    {
                        "serviceId": "ai4bharat/conformer-hi-gpu--t4",
                        "modelId": "648025f27cdd753e77f461a9",
                        "language": {
                            "sourceLanguage": "hi",
                            "sourceScriptCode": "Deva"
                        },
                        "domain": [
                            "general"
                        ]
                    },
                    {
                        "serviceId": "ai4bharat/conformer-multilingual-dravidian-gpu--t4",
                        "modelId": "641174a356e9de23f65b5429",
                        "language": {
                            "sourceLanguage": "kn",
                            "sourceScriptCode": "Knda"
                        },
                        "domain": [
                            "general"
                        ]
                    },
                    {
                        "serviceId": "ai4bharat/conformer-multilingual-dravidian-gpu--t4",
                        "modelId": "6411749856e9de23f65b5428",
                        "language": {
                            "sourceLanguage": "ml",
                            "sourceScriptCode": "Mlym"
                        },
                        "domain": [
                            "general"
                        ]
                    },
                    {
                        "serviceId": "ai4bharat/conformer-multilingual-indo_aryan-gpu--t4",
                        "modelId": "6411744b56e9de23f65b5424",
                        "language": {
                            "sourceLanguage": "mr",
                            "sourceScriptCode": "Deva"
                        },
                        "domain": [
                            "general"
                        ]
                    },
                    {
                        "serviceId": "ai4bharat/conformer-multilingual-indo_aryan-gpu--t4",
                        "modelId": "64117440b1463435d2fbaec3",
                        "language": {
                            "sourceLanguage": "or",
                            "sourceScriptCode": "Orya"
                        },
                        "domain": [
                            "general"
                        ]
                    },
                    {
                        "serviceId": "ai4bharat/conformer-multilingual-indo_aryan-gpu--t4",
                        "modelId": "6411743456e9de23f65b5423",
                        "language": {
                            "sourceLanguage": "pa",
                            "sourceScriptCode": "Guru"
                        },
                        "domain": [
                            "general"
                        ]
                    },
                    {
                        "serviceId": "ai4bharat/conformer-multilingual-indo_aryan-gpu--t4",
                        "modelId": "6411742856e9de23f65b5422",
                        "language": {
                            "sourceLanguage": "sa",
                            "sourceScriptCode": "Deva"
                        },
                        "domain": [
                            "general"
                        ]
                    },
                    {
                        "serviceId": "ai4bharat/conformer-multilingual-dravidian-gpu--t4",
                        "modelId": "641174ad56e9de23f65b542a",
                        "language": {
                            "sourceLanguage": "ta",
                            "sourceScriptCode": "Taml"
                        },
                        "domain": [
                            "general"
                        ]
                    },
                    {
                        "serviceId": "ai4bharat/conformer-multilingual-dravidian-gpu--t4",
                        "modelId": "6411748db1463435d2fbaec5",
                        "language": {
                            "sourceLanguage": "te",
                            "sourceScriptCode": "Telu"
                        },
                        "domain": [
                            "general"
                        ]
                    },
                    {
                        "serviceId": "ai4bharat/conformer-multilingual-indo_aryan-gpu--t4",
                        "modelId": "6411741c56e9de23f65b5421",
                        "language": {
                            "sourceLanguage": "ur",
                            "sourceScriptCode": "Aran"
                        },
                        "domain": [
                            "general"
                        ]
                    }
                ]
            },
            {
                "taskType": "translation",
                "config": [
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1d3e8ecee6735a1b3793",
                        "language": {
                            "sourceLanguage": "bn",
                            "sourceScriptCode": "Beng",
                            "targetLanguage": "en",
                            "targetScriptCode": "Latn"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1d238ecee6735a1b3778",
                        "language": {
                            "sourceLanguage": "bn",
                            "sourceScriptCode": "Beng",
                            "targetLanguage": "as",
                            "targetScriptCode": "Beng"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1d4c92a6a31751ff1f35",
                        "language": {
                            "sourceLanguage": "bn",
                            "sourceScriptCode": "Beng",
                            "targetLanguage": "brx",
                            "targetScriptCode": "Deva"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1dd192a6a31751ff1fb1",
                        "language": {
                            "sourceLanguage": "bn",
                            "sourceScriptCode": "Beng",
                            "targetLanguage": "gu",
                            "targetScriptCode": "Gujr"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1d1492a6a31751ff1f06",
                        "language": {
                            "sourceLanguage": "bn",
                            "sourceScriptCode": "Beng",
                            "targetLanguage": "hi",
                            "targetScriptCode": "Deva"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1d708ecee6735a1b37b9",
                        "language": {
                            "sourceLanguage": "bn",
                            "sourceScriptCode": "Beng",
                            "targetLanguage": "kn",
                            "targetScriptCode": "Knda"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1c8492a6a31751ff1e96",
                        "language": {
                            "sourceLanguage": "bn",
                            "sourceScriptCode": "Beng",
                            "targetLanguage": "ml",
                            "targetScriptCode": "Mlym"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1da68ecee6735a1b37e2",
                        "language": {
                            "sourceLanguage": "bn",
                            "sourceScriptCode": "Beng",
                            "targetLanguage": "mni",
                            "targetScriptCode": "Mtei"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1c7a8ecee6735a1b36dd",
                        "language": {
                            "sourceLanguage": "bn",
                            "sourceScriptCode": "Beng",
                            "targetLanguage": "mni",
                            "targetScriptCode": "Beng"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1dc18ecee6735a1b37f8",
                        "language": {
                            "sourceLanguage": "bn",
                            "sourceScriptCode": "Beng",
                            "targetLanguage": "mr",
                            "targetScriptCode": "Deva"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1d1b92a6a31751ff1f0d",
                        "language": {
                            "sourceLanguage": "bn",
                            "sourceScriptCode": "Beng",
                            "targetLanguage": "or",
                            "targetScriptCode": "Orya"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1d398ecee6735a1b378c",
                        "language": {
                            "sourceLanguage": "bn",
                            "sourceScriptCode": "Beng",
                            "targetLanguage": "pa",
                            "targetScriptCode": "Guru"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1ce092a6a31751ff1ee5",
                        "language": {
                            "sourceLanguage": "bn",
                            "sourceScriptCode": "Beng",
                            "targetLanguage": "ta",
                            "targetScriptCode": "Taml"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1c838ecee6735a1b36ea",
                        "language": {
                            "sourceLanguage": "bn",
                            "sourceScriptCode": "Beng",
                            "targetLanguage": "te",
                            "targetScriptCode": "Telu"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1cc98ecee6735a1b371e",
                        "language": {
                            "sourceLanguage": "en",
                            "sourceScriptCode": "Latn",
                            "targetLanguage": "as",
                            "targetScriptCode": "Beng"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1d818ecee6735a1b37c7",
                        "language": {
                            "sourceLanguage": "en",
                            "sourceScriptCode": "Latn",
                            "targetLanguage": "bn",
                            "targetScriptCode": "Beng"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1c738ecee6735a1b36d6",
                        "language": {
                            "sourceLanguage": "en",
                            "sourceScriptCode": "Latn",
                            "targetLanguage": "brx",
                            "targetScriptCode": "Deva"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1cae8ecee6735a1b370d",
                        "language": {
                            "sourceLanguage": "en",
                            "sourceScriptCode": "Latn",
                            "targetLanguage": "gu",
                            "targetScriptCode": "Gujr"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1d6592a6a31751ff1f49",
                        "language": {
                            "sourceLanguage": "en",
                            "sourceScriptCode": "Latn",
                            "targetLanguage": "hi",
                            "targetScriptCode": "Deva"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1c788ecee6735a1b36db",
                        "language": {
                            "sourceLanguage": "en",
                            "sourceScriptCode": "Latn",
                            "targetLanguage": "kn",
                            "targetScriptCode": "Knda"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1c6c8ecee6735a1b36d1",
                        "language": {
                            "sourceLanguage": "en",
                            "sourceScriptCode": "Latn",
                            "targetLanguage": "ml",
                            "targetScriptCode": "Mlym"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1db892a6a31751ff1f97",
                        "language": {
                            "sourceLanguage": "en",
                            "sourceScriptCode": "Latn",
                            "targetLanguage": "mni",
                            "targetScriptCode": "Mtei"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1d2a8ecee6735a1b377e",
                        "language": {
                            "sourceLanguage": "en",
                            "sourceScriptCode": "Latn",
                            "targetLanguage": "mni",
                            "targetScriptCode": "Beng"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1d7c8ecee6735a1b37c3",
                        "language": {
                            "sourceLanguage": "en",
                            "sourceScriptCode": "Latn",
                            "targetLanguage": "mr",
                            "targetScriptCode": "Deva"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1dd98ecee6735a1b380c",
                        "language": {
                            "sourceLanguage": "en",
                            "sourceScriptCode": "Latn",
                            "targetLanguage": "or",
                            "targetScriptCode": "Orya"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1c6c8ecee6735a1b36d2",
                        "language": {
                            "sourceLanguage": "en",
                            "sourceScriptCode": "Latn",
                            "targetLanguage": "pa",
                            "targetScriptCode": "Guru"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1caa92a6a31751ff1eb6",
                        "language": {
                            "sourceLanguage": "en",
                            "sourceScriptCode": "Latn",
                            "targetLanguage": "ta",
                            "targetScriptCode": "Taml"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1cab8ecee6735a1b370b",
                        "language": {
                            "sourceLanguage": "en",
                            "sourceScriptCode": "Latn",
                            "targetLanguage": "te",
                            "targetScriptCode": "Telu"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1c9392a6a31751ff1ea0",
                        "language": {
                            "sourceLanguage": "gu",
                            "sourceScriptCode": "Gujr",
                            "targetLanguage": "en",
                            "targetScriptCode": "Latn"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1cba92a6a31751ff1ec5",
                        "language": {
                            "sourceLanguage": "gu",
                            "sourceScriptCode": "Gujr",
                            "targetLanguage": "as",
                            "targetScriptCode": "Beng"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1c9d92a6a31751ff1eab",
                        "language": {
                            "sourceLanguage": "gu",
                            "sourceScriptCode": "Gujr",
                            "targetLanguage": "bn",
                            "targetScriptCode": "Beng"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1d248ecee6735a1b3779",
                        "language": {
                            "sourceLanguage": "gu",
                            "sourceScriptCode": "Gujr",
                            "targetLanguage": "brx",
                            "targetScriptCode": "Deva"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1d548ecee6735a1b37a0",
                        "language": {
                            "sourceLanguage": "gu",
                            "sourceScriptCode": "Gujr",
                            "targetLanguage": "hi",
                            "targetScriptCode": "Deva"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1d9392a6a31751ff1f73",
                        "language": {
                            "sourceLanguage": "gu",
                            "sourceScriptCode": "Gujr",
                            "targetLanguage": "kn",
                            "targetScriptCode": "Knda"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1d4d92a6a31751ff1f37",
                        "language": {
                            "sourceLanguage": "gu",
                            "sourceScriptCode": "Gujr",
                            "targetLanguage": "ml",
                            "targetScriptCode": "Mlym"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1c9c92a6a31751ff1ea9",
                        "language": {
                            "sourceLanguage": "gu",
                            "sourceScriptCode": "Gujr",
                            "targetLanguage": "mni",
                            "targetScriptCode": "Mtei"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1cb292a6a31751ff1ebe",
                        "language": {
                            "sourceLanguage": "gu",
                            "sourceScriptCode": "Gujr",
                            "targetLanguage": "mni",
                            "targetScriptCode": "Beng"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1d378ecee6735a1b3789",
                        "language": {
                            "sourceLanguage": "gu",
                            "sourceScriptCode": "Gujr",
                            "targetLanguage": "mr",
                            "targetScriptCode": "Deva"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1dd992a6a31751ff1fb8",
                        "language": {
                            "sourceLanguage": "gu",
                            "sourceScriptCode": "Gujr",
                            "targetLanguage": "or",
                            "targetScriptCode": "Orya"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1caa8ecee6735a1b3709",
                        "language": {
                            "sourceLanguage": "gu",
                            "sourceScriptCode": "Gujr",
                            "targetLanguage": "pa",
                            "targetScriptCode": "Guru"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1ddc92a6a31751ff1fbb",
                        "language": {
                            "sourceLanguage": "gu",
                            "sourceScriptCode": "Gujr",
                            "targetLanguage": "ta",
                            "targetScriptCode": "Taml"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1cd192a6a31751ff1ed7",
                        "language": {
                            "sourceLanguage": "gu",
                            "sourceScriptCode": "Gujr",
                            "targetLanguage": "te",
                            "targetScriptCode": "Telu"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1cd18ecee6735a1b372a",
                        "language": {
                            "sourceLanguage": "hi",
                            "sourceScriptCode": "Deva",
                            "targetLanguage": "en",
                            "targetScriptCode": "Latn"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1d9b92a6a31751ff1f77",
                        "language": {
                            "sourceLanguage": "hi",
                            "sourceScriptCode": "Deva",
                            "targetLanguage": "as",
                            "targetScriptCode": "Beng"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1dba8ecee6735a1b37f1",
                        "language": {
                            "sourceLanguage": "hi",
                            "sourceScriptCode": "Deva",
                            "targetLanguage": "bn",
                            "targetScriptCode": "Beng"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1c8b92a6a31751ff1e9a",
                        "language": {
                            "sourceLanguage": "hi",
                            "sourceScriptCode": "Deva",
                            "targetLanguage": "brx",
                            "targetScriptCode": "Deva"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1d7892a6a31751ff1f5a",
                        "language": {
                            "sourceLanguage": "hi",
                            "sourceScriptCode": "Deva",
                            "targetLanguage": "gu",
                            "targetScriptCode": "Gujr"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1cb692a6a31751ff1ec2",
                        "language": {
                            "sourceLanguage": "hi",
                            "sourceScriptCode": "Deva",
                            "targetLanguage": "kn",
                            "targetScriptCode": "Knda"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1d6892a6a31751ff1f4d",
                        "language": {
                            "sourceLanguage": "hi",
                            "sourceScriptCode": "Deva",
                            "targetLanguage": "ml",
                            "targetScriptCode": "Mlym"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1d9892a6a31751ff1f76",
                        "language": {
                            "sourceLanguage": "hi",
                            "sourceScriptCode": "Deva",
                            "targetLanguage": "mni",
                            "targetScriptCode": "Mtei"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1d1e8ecee6735a1b3774",
                        "language": {
                            "sourceLanguage": "hi",
                            "sourceScriptCode": "Deva",
                            "targetLanguage": "mni",
                            "targetScriptCode": "Beng"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1dd78ecee6735a1b380b",
                        "language": {
                            "sourceLanguage": "hi",
                            "sourceScriptCode": "Deva",
                            "targetLanguage": "mr",
                            "targetScriptCode": "Deva"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1d0692a6a31751ff1efd",
                        "language": {
                            "sourceLanguage": "hi",
                            "sourceScriptCode": "Deva",
                            "targetLanguage": "or",
                            "targetScriptCode": "Orya"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1cc492a6a31751ff1ecf",
                        "language": {
                            "sourceLanguage": "hi",
                            "sourceScriptCode": "Deva",
                            "targetLanguage": "pa",
                            "targetScriptCode": "Guru"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1db68ecee6735a1b37ef",
                        "language": {
                            "sourceLanguage": "hi",
                            "sourceScriptCode": "Deva",
                            "targetLanguage": "ta",
                            "targetScriptCode": "Taml"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1dc692a6a31751ff1fa2",
                        "language": {
                            "sourceLanguage": "hi",
                            "sourceScriptCode": "Deva",
                            "targetLanguage": "te",
                            "targetScriptCode": "Telu"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1d6392a6a31751ff1f48",
                        "language": {
                            "sourceLanguage": "kn",
                            "sourceScriptCode": "Knda",
                            "targetLanguage": "en",
                            "targetScriptCode": "Latn"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1cb78ecee6735a1b3712",
                        "language": {
                            "sourceLanguage": "kn",
                            "sourceScriptCode": "Knda",
                            "targetLanguage": "as",
                            "targetScriptCode": "Beng"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1c828ecee6735a1b36e8",
                        "language": {
                            "sourceLanguage": "kn",
                            "sourceScriptCode": "Knda",
                            "targetLanguage": "bn",
                            "targetScriptCode": "Beng"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1d798ecee6735a1b37c0",
                        "language": {
                            "sourceLanguage": "kn",
                            "sourceScriptCode": "Knda",
                            "targetLanguage": "brx",
                            "targetScriptCode": "Deva"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1c7092a6a31751ff1e89",
                        "language": {
                            "sourceLanguage": "kn",
                            "sourceScriptCode": "Knda",
                            "targetLanguage": "gu",
                            "targetScriptCode": "Gujr"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1cc492a6a31751ff1ece",
                        "language": {
                            "sourceLanguage": "kn",
                            "sourceScriptCode": "Knda",
                            "targetLanguage": "hi",
                            "targetScriptCode": "Deva"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1c9f92a6a31751ff1ead",
                        "language": {
                            "sourceLanguage": "kn",
                            "sourceScriptCode": "Knda",
                            "targetLanguage": "ml",
                            "targetScriptCode": "Mlym"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1cbb92a6a31751ff1ec7",
                        "language": {
                            "sourceLanguage": "kn",
                            "sourceScriptCode": "Knda",
                            "targetLanguage": "mni",
                            "targetScriptCode": "Mtei"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1cbb92a6a31751ff1ec6",
                        "language": {
                            "sourceLanguage": "kn",
                            "sourceScriptCode": "Knda",
                            "targetLanguage": "mni",
                            "targetScriptCode": "Beng"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1d378ecee6735a1b378a",
                        "language": {
                            "sourceLanguage": "kn",
                            "sourceScriptCode": "Knda",
                            "targetLanguage": "mr",
                            "targetScriptCode": "Deva"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1dc08ecee6735a1b37f6",
                        "language": {
                            "sourceLanguage": "kn",
                            "sourceScriptCode": "Knda",
                            "targetLanguage": "or",
                            "targetScriptCode": "Orya"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1cce92a6a31751ff1ed6",
                        "language": {
                            "sourceLanguage": "kn",
                            "sourceScriptCode": "Knda",
                            "targetLanguage": "pa",
                            "targetScriptCode": "Guru"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1cea92a6a31751ff1eeb",
                        "language": {
                            "sourceLanguage": "kn",
                            "sourceScriptCode": "Knda",
                            "targetLanguage": "ta",
                            "targetScriptCode": "Taml"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1cfd92a6a31751ff1ef8",
                        "language": {
                            "sourceLanguage": "kn",
                            "sourceScriptCode": "Knda",
                            "targetLanguage": "te",
                            "targetScriptCode": "Telu"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1d1392a6a31751ff1f05",
                        "language": {
                            "sourceLanguage": "ml",
                            "sourceScriptCode": "Mlym",
                            "targetLanguage": "en",
                            "targetScriptCode": "Latn"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1c988ecee6735a1b36fc",
                        "language": {
                            "sourceLanguage": "ml",
                            "sourceScriptCode": "Mlym",
                            "targetLanguage": "as",
                            "targetScriptCode": "Beng"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1d338ecee6735a1b3786",
                        "language": {
                            "sourceLanguage": "ml",
                            "sourceScriptCode": "Mlym",
                            "targetLanguage": "bn",
                            "targetScriptCode": "Beng"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1d1492a6a31751ff1f07",
                        "language": {
                            "sourceLanguage": "ml",
                            "sourceScriptCode": "Mlym",
                            "targetLanguage": "brx",
                            "targetScriptCode": "Deva"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1d1a8ecee6735a1b376f",
                        "language": {
                            "sourceLanguage": "ml",
                            "sourceScriptCode": "Mlym",
                            "targetLanguage": "gu",
                            "targetScriptCode": "Gujr"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1d5e8ecee6735a1b37a9",
                        "language": {
                            "sourceLanguage": "ml",
                            "sourceScriptCode": "Mlym",
                            "targetLanguage": "hi",
                            "targetScriptCode": "Deva"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1d0d92a6a31751ff1f02",
                        "language": {
                            "sourceLanguage": "ml",
                            "sourceScriptCode": "Mlym",
                            "targetLanguage": "kn",
                            "targetScriptCode": "Knda"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1d4892a6a31751ff1f30",
                        "language": {
                            "sourceLanguage": "ml",
                            "sourceScriptCode": "Mlym",
                            "targetLanguage": "mni",
                            "targetScriptCode": "Mtei"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1db292a6a31751ff1f92",
                        "language": {
                            "sourceLanguage": "ml",
                            "sourceScriptCode": "Mlym",
                            "targetLanguage": "mni",
                            "targetScriptCode": "Beng"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1d2f8ecee6735a1b3782",
                        "language": {
                            "sourceLanguage": "ml",
                            "sourceScriptCode": "Mlym",
                            "targetLanguage": "mr",
                            "targetScriptCode": "Deva"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1d968ecee6735a1b37d2",
                        "language": {
                            "sourceLanguage": "ml",
                            "sourceScriptCode": "Mlym",
                            "targetLanguage": "or",
                            "targetScriptCode": "Orya"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1d088ecee6735a1b375e",
                        "language": {
                            "sourceLanguage": "ml",
                            "sourceScriptCode": "Mlym",
                            "targetLanguage": "pa",
                            "targetScriptCode": "Guru"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1cd792a6a31751ff1edd",
                        "language": {
                            "sourceLanguage": "ml",
                            "sourceScriptCode": "Mlym",
                            "targetLanguage": "ta",
                            "targetScriptCode": "Taml"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1c9692a6a31751ff1ea3",
                        "language": {
                            "sourceLanguage": "ml",
                            "sourceScriptCode": "Mlym",
                            "targetLanguage": "te",
                            "targetScriptCode": "Telu"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1cc792a6a31751ff1ed4",
                        "language": {
                            "sourceLanguage": "mr",
                            "sourceScriptCode": "Deva",
                            "targetLanguage": "en",
                            "targetScriptCode": "Latn"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1da592a6a31751ff1f83",
                        "language": {
                            "sourceLanguage": "mr",
                            "sourceScriptCode": "Deva",
                            "targetLanguage": "as",
                            "targetScriptCode": "Beng"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1cbe92a6a31751ff1ec9",
                        "language": {
                            "sourceLanguage": "mr",
                            "sourceScriptCode": "Deva",
                            "targetLanguage": "bn",
                            "targetScriptCode": "Beng"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1d0f8ecee6735a1b3765",
                        "language": {
                            "sourceLanguage": "mr",
                            "sourceScriptCode": "Deva",
                            "targetLanguage": "brx",
                            "targetScriptCode": "Deva"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1c7792a6a31751ff1e91",
                        "language": {
                            "sourceLanguage": "mr",
                            "sourceScriptCode": "Deva",
                            "targetLanguage": "gu",
                            "targetScriptCode": "Gujr"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1d498ecee6735a1b379a",
                        "language": {
                            "sourceLanguage": "mr",
                            "sourceScriptCode": "Deva",
                            "targetLanguage": "hi",
                            "targetScriptCode": "Deva"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1ce28ecee6735a1b3737",
                        "language": {
                            "sourceLanguage": "mr",
                            "sourceScriptCode": "Deva",
                            "targetLanguage": "kn",
                            "targetScriptCode": "Knda"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1cb78ecee6735a1b3713",
                        "language": {
                            "sourceLanguage": "mr",
                            "sourceScriptCode": "Deva",
                            "targetLanguage": "ml",
                            "targetScriptCode": "Mlym"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1c8092a6a31751ff1e95",
                        "language": {
                            "sourceLanguage": "mr",
                            "sourceScriptCode": "Deva",
                            "targetLanguage": "mni",
                            "targetScriptCode": "Mtei"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1d2992a6a31751ff1f18",
                        "language": {
                            "sourceLanguage": "mr",
                            "sourceScriptCode": "Deva",
                            "targetLanguage": "mni",
                            "targetScriptCode": "Beng"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1ce68ecee6735a1b373a",
                        "language": {
                            "sourceLanguage": "mr",
                            "sourceScriptCode": "Deva",
                            "targetLanguage": "or",
                            "targetScriptCode": "Orya"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1cbf92a6a31751ff1eca",
                        "language": {
                            "sourceLanguage": "mr",
                            "sourceScriptCode": "Deva",
                            "targetLanguage": "pa",
                            "targetScriptCode": "Guru"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1dc092a6a31751ff1f9f",
                        "language": {
                            "sourceLanguage": "mr",
                            "sourceScriptCode": "Deva",
                            "targetLanguage": "ta",
                            "targetScriptCode": "Taml"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1dce8ecee6735a1b3804",
                        "language": {
                            "sourceLanguage": "mr",
                            "sourceScriptCode": "Deva",
                            "targetLanguage": "te",
                            "targetScriptCode": "Telu"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1d058ecee6735a1b375c",
                        "language": {
                            "sourceLanguage": "or",
                            "sourceScriptCode": "Orya",
                            "targetLanguage": "en",
                            "targetScriptCode": "Latn"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1d128ecee6735a1b3769",
                        "language": {
                            "sourceLanguage": "or",
                            "sourceScriptCode": "Orya",
                            "targetLanguage": "as",
                            "targetScriptCode": "Beng"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1c6f8ecee6735a1b36d4",
                        "language": {
                            "sourceLanguage": "or",
                            "sourceScriptCode": "Orya",
                            "targetLanguage": "bn",
                            "targetScriptCode": "Beng"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1cc28ecee6735a1b371b",
                        "language": {
                            "sourceLanguage": "or",
                            "sourceScriptCode": "Orya",
                            "targetLanguage": "brx",
                            "targetScriptCode": "Deva"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1d3292a6a31751ff1f20",
                        "language": {
                            "sourceLanguage": "or",
                            "sourceScriptCode": "Orya",
                            "targetLanguage": "gu",
                            "targetScriptCode": "Gujr"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1c8f8ecee6735a1b36f6",
                        "language": {
                            "sourceLanguage": "or",
                            "sourceScriptCode": "Orya",
                            "targetLanguage": "hi",
                            "targetScriptCode": "Deva"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1daf8ecee6735a1b37e7",
                        "language": {
                            "sourceLanguage": "or",
                            "sourceScriptCode": "Orya",
                            "targetLanguage": "kn",
                            "targetScriptCode": "Knda"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1dde8ecee6735a1b3811",
                        "language": {
                            "sourceLanguage": "or",
                            "sourceScriptCode": "Orya",
                            "targetLanguage": "ml",
                            "targetScriptCode": "Mlym"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1d4e8ecee6735a1b379b",
                        "language": {
                            "sourceLanguage": "or",
                            "sourceScriptCode": "Orya",
                            "targetLanguage": "mni",
                            "targetScriptCode": "Mtei"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1db58ecee6735a1b37ec",
                        "language": {
                            "sourceLanguage": "or",
                            "sourceScriptCode": "Orya",
                            "targetLanguage": "mni",
                            "targetScriptCode": "Beng"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1ce592a6a31751ff1eea",
                        "language": {
                            "sourceLanguage": "or",
                            "sourceScriptCode": "Orya",
                            "targetLanguage": "mr",
                            "targetScriptCode": "Deva"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1d3d8ecee6735a1b3792",
                        "language": {
                            "sourceLanguage": "or",
                            "sourceScriptCode": "Orya",
                            "targetLanguage": "pa",
                            "targetScriptCode": "Guru"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1d2692a6a31751ff1f16",
                        "language": {
                            "sourceLanguage": "or",
                            "sourceScriptCode": "Orya",
                            "targetLanguage": "ta",
                            "targetScriptCode": "Taml"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1c858ecee6735a1b36eb",
                        "language": {
                            "sourceLanguage": "or",
                            "sourceScriptCode": "Orya",
                            "targetLanguage": "te",
                            "targetScriptCode": "Telu"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1d8392a6a31751ff1f63",
                        "language": {
                            "sourceLanguage": "pa",
                            "sourceScriptCode": "Guru",
                            "targetLanguage": "en",
                            "targetScriptCode": "Latn"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1d0e8ecee6735a1b3764",
                        "language": {
                            "sourceLanguage": "pa",
                            "sourceScriptCode": "Guru",
                            "targetLanguage": "as",
                            "targetScriptCode": "Beng"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1d0c92a6a31751ff1f01",
                        "language": {
                            "sourceLanguage": "pa",
                            "sourceScriptCode": "Guru",
                            "targetLanguage": "bn",
                            "targetScriptCode": "Beng"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1dbc8ecee6735a1b37f3",
                        "language": {
                            "sourceLanguage": "pa",
                            "sourceScriptCode": "Guru",
                            "targetLanguage": "brx",
                            "targetScriptCode": "Deva"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1cfb8ecee6735a1b3750",
                        "language": {
                            "sourceLanguage": "pa",
                            "sourceScriptCode": "Guru",
                            "targetLanguage": "gu",
                            "targetScriptCode": "Gujr"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1ce78ecee6735a1b373b",
                        "language": {
                            "sourceLanguage": "pa",
                            "sourceScriptCode": "Guru",
                            "targetLanguage": "hi",
                            "targetScriptCode": "Deva"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1da88ecee6735a1b37e3",
                        "language": {
                            "sourceLanguage": "pa",
                            "sourceScriptCode": "Guru",
                            "targetLanguage": "kn",
                            "targetScriptCode": "Knda"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1d9a8ecee6735a1b37da",
                        "language": {
                            "sourceLanguage": "pa",
                            "sourceScriptCode": "Guru",
                            "targetLanguage": "ml",
                            "targetScriptCode": "Mlym"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1d8e92a6a31751ff1f6c",
                        "language": {
                            "sourceLanguage": "pa",
                            "sourceScriptCode": "Guru",
                            "targetLanguage": "mni",
                            "targetScriptCode": "Mtei"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1dbc92a6a31751ff1f9b",
                        "language": {
                            "sourceLanguage": "pa",
                            "sourceScriptCode": "Guru",
                            "targetLanguage": "mni",
                            "targetScriptCode": "Beng"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1d278ecee6735a1b377c",
                        "language": {
                            "sourceLanguage": "pa",
                            "sourceScriptCode": "Guru",
                            "targetLanguage": "mr",
                            "targetScriptCode": "Deva"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1cfc8ecee6735a1b3752",
                        "language": {
                            "sourceLanguage": "pa",
                            "sourceScriptCode": "Guru",
                            "targetLanguage": "or",
                            "targetScriptCode": "Orya"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1ddd8ecee6735a1b3810",
                        "language": {
                            "sourceLanguage": "pa",
                            "sourceScriptCode": "Guru",
                            "targetLanguage": "ta",
                            "targetScriptCode": "Taml"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1ca092a6a31751ff1eaf",
                        "language": {
                            "sourceLanguage": "pa",
                            "sourceScriptCode": "Guru",
                            "targetLanguage": "te",
                            "targetScriptCode": "Telu"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1ca78ecee6735a1b3705",
                        "language": {
                            "sourceLanguage": "sa",
                            "sourceScriptCode": "Deva",
                            "targetLanguage": "en",
                            "targetScriptCode": "Latn"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1ccd8ecee6735a1b3724",
                        "language": {
                            "sourceLanguage": "sa",
                            "sourceScriptCode": "Deva",
                            "targetLanguage": "as",
                            "targetScriptCode": "Beng"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1ca492a6a31751ff1eb2",
                        "language": {
                            "sourceLanguage": "sa",
                            "sourceScriptCode": "Deva",
                            "targetLanguage": "bn",
                            "targetScriptCode": "Beng"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1d738ecee6735a1b37bc",
                        "language": {
                            "sourceLanguage": "sa",
                            "sourceScriptCode": "Deva",
                            "targetLanguage": "brx",
                            "targetScriptCode": "Deva"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1dc492a6a31751ff1fa1",
                        "language": {
                            "sourceLanguage": "sa",
                            "sourceScriptCode": "Deva",
                            "targetLanguage": "gu",
                            "targetScriptCode": "Gujr"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1d778ecee6735a1b37be",
                        "language": {
                            "sourceLanguage": "sa",
                            "sourceScriptCode": "Deva",
                            "targetLanguage": "hi",
                            "targetScriptCode": "Deva"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1d138ecee6735a1b376a",
                        "language": {
                            "sourceLanguage": "sa",
                            "sourceScriptCode": "Deva",
                            "targetLanguage": "kn",
                            "targetScriptCode": "Knda"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1d028ecee6735a1b3757",
                        "language": {
                            "sourceLanguage": "sa",
                            "sourceScriptCode": "Deva",
                            "targetLanguage": "ml",
                            "targetScriptCode": "Mlym"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1cdf92a6a31751ff1ee4",
                        "language": {
                            "sourceLanguage": "sa",
                            "sourceScriptCode": "Deva",
                            "targetLanguage": "mni",
                            "targetScriptCode": "Mtei"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1de992a6a31751ff1fc5",
                        "language": {
                            "sourceLanguage": "sa",
                            "sourceScriptCode": "Deva",
                            "targetLanguage": "mni",
                            "targetScriptCode": "Beng"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1cee8ecee6735a1b3743",
                        "language": {
                            "sourceLanguage": "sa",
                            "sourceScriptCode": "Deva",
                            "targetLanguage": "mr",
                            "targetScriptCode": "Deva"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1c878ecee6735a1b36ed",
                        "language": {
                            "sourceLanguage": "sa",
                            "sourceScriptCode": "Deva",
                            "targetLanguage": "or",
                            "targetScriptCode": "Orya"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1cad92a6a31751ff1eb7",
                        "language": {
                            "sourceLanguage": "sa",
                            "sourceScriptCode": "Deva",
                            "targetLanguage": "pa",
                            "targetScriptCode": "Guru"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1cdd92a6a31751ff1ee2",
                        "language": {
                            "sourceLanguage": "sa",
                            "sourceScriptCode": "Deva",
                            "targetLanguage": "ta",
                            "targetScriptCode": "Taml"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1d598ecee6735a1b37a5",
                        "language": {
                            "sourceLanguage": "sa",
                            "sourceScriptCode": "Deva",
                            "targetLanguage": "te",
                            "targetScriptCode": "Telu"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1d2d92a6a31751ff1f1d",
                        "language": {
                            "sourceLanguage": "ta",
                            "sourceScriptCode": "Taml",
                            "targetLanguage": "en",
                            "targetScriptCode": "Latn"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1c9492a6a31751ff1ea1",
                        "language": {
                            "sourceLanguage": "ta",
                            "sourceScriptCode": "Taml",
                            "targetLanguage": "as",
                            "targetScriptCode": "Beng"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1d2992a6a31751ff1f19",
                        "language": {
                            "sourceLanguage": "ta",
                            "sourceScriptCode": "Taml",
                            "targetLanguage": "bn",
                            "targetScriptCode": "Beng"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1d4d92a6a31751ff1f36",
                        "language": {
                            "sourceLanguage": "ta",
                            "sourceScriptCode": "Taml",
                            "targetLanguage": "brx",
                            "targetScriptCode": "Deva"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1d098ecee6735a1b3760",
                        "language": {
                            "sourceLanguage": "ta",
                            "sourceScriptCode": "Taml",
                            "targetLanguage": "gu",
                            "targetScriptCode": "Gujr"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1c9b8ecee6735a1b36fe",
                        "language": {
                            "sourceLanguage": "ta",
                            "sourceScriptCode": "Taml",
                            "targetLanguage": "hi",
                            "targetScriptCode": "Deva"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1d2892a6a31751ff1f17",
                        "language": {
                            "sourceLanguage": "ta",
                            "sourceScriptCode": "Taml",
                            "targetLanguage": "kn",
                            "targetScriptCode": "Knda"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1d358ecee6735a1b3788",
                        "language": {
                            "sourceLanguage": "ta",
                            "sourceScriptCode": "Taml",
                            "targetLanguage": "ml",
                            "targetScriptCode": "Mlym"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1de68ecee6735a1b3819",
                        "language": {
                            "sourceLanguage": "ta",
                            "sourceScriptCode": "Taml",
                            "targetLanguage": "mni",
                            "targetScriptCode": "Mtei"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1dac92a6a31751ff1f8b",
                        "language": {
                            "sourceLanguage": "ta",
                            "sourceScriptCode": "Taml",
                            "targetLanguage": "mni",
                            "targetScriptCode": "Beng"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1ca68ecee6735a1b3703",
                        "language": {
                            "sourceLanguage": "ta",
                            "sourceScriptCode": "Taml",
                            "targetLanguage": "mr",
                            "targetScriptCode": "Deva"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1d3e92a6a31751ff1f26",
                        "language": {
                            "sourceLanguage": "ta",
                            "sourceScriptCode": "Taml",
                            "targetLanguage": "or",
                            "targetScriptCode": "Orya"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1d698ecee6735a1b37b3",
                        "language": {
                            "sourceLanguage": "ta",
                            "sourceScriptCode": "Taml",
                            "targetLanguage": "pa",
                            "targetScriptCode": "Guru"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1d1892a6a31751ff1f0a",
                        "language": {
                            "sourceLanguage": "ta",
                            "sourceScriptCode": "Taml",
                            "targetLanguage": "te",
                            "targetScriptCode": "Telu"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1ca98ecee6735a1b3707",
                        "language": {
                            "sourceLanguage": "te",
                            "sourceScriptCode": "Telu",
                            "targetLanguage": "en",
                            "targetScriptCode": "Latn"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1ce98ecee6735a1b373e",
                        "language": {
                            "sourceLanguage": "te",
                            "sourceScriptCode": "Telu",
                            "targetLanguage": "as",
                            "targetScriptCode": "Beng"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1d898ecee6735a1b37cc",
                        "language": {
                            "sourceLanguage": "te",
                            "sourceScriptCode": "Telu",
                            "targetLanguage": "bn",
                            "targetScriptCode": "Beng"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1d178ecee6735a1b376c",
                        "language": {
                            "sourceLanguage": "te",
                            "sourceScriptCode": "Telu",
                            "targetLanguage": "brx",
                            "targetScriptCode": "Deva"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1c7492a6a31751ff1e90",
                        "language": {
                            "sourceLanguage": "te",
                            "sourceScriptCode": "Telu",
                            "targetLanguage": "gu",
                            "targetScriptCode": "Gujr"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1d8b92a6a31751ff1f6a",
                        "language": {
                            "sourceLanguage": "te",
                            "sourceScriptCode": "Telu",
                            "targetLanguage": "hi",
                            "targetScriptCode": "Deva"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1dcc8ecee6735a1b3802",
                        "language": {
                            "sourceLanguage": "te",
                            "sourceScriptCode": "Telu",
                            "targetLanguage": "kn",
                            "targetScriptCode": "Knda"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1d4b92a6a31751ff1f34",
                        "language": {
                            "sourceLanguage": "te",
                            "sourceScriptCode": "Telu",
                            "targetLanguage": "ml",
                            "targetScriptCode": "Mlym"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1d1d8ecee6735a1b3772",
                        "language": {
                            "sourceLanguage": "te",
                            "sourceScriptCode": "Telu",
                            "targetLanguage": "mni",
                            "targetScriptCode": "Mtei"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1d5d92a6a31751ff1f44",
                        "language": {
                            "sourceLanguage": "te",
                            "sourceScriptCode": "Telu",
                            "targetLanguage": "mni",
                            "targetScriptCode": "Beng"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1cd08ecee6735a1b3728",
                        "language": {
                            "sourceLanguage": "te",
                            "sourceScriptCode": "Telu",
                            "targetLanguage": "mr",
                            "targetScriptCode": "Deva"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1d9e92a6a31751ff1f7c",
                        "language": {
                            "sourceLanguage": "te",
                            "sourceScriptCode": "Telu",
                            "targetLanguage": "or",
                            "targetScriptCode": "Orya"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1c818ecee6735a1b36e7",
                        "language": {
                            "sourceLanguage": "te",
                            "sourceScriptCode": "Telu",
                            "targetLanguage": "pa",
                            "targetScriptCode": "Guru"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1cef92a6a31751ff1eee",
                        "language": {
                            "sourceLanguage": "te",
                            "sourceScriptCode": "Telu",
                            "targetLanguage": "ta",
                            "targetScriptCode": "Taml"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1d9a8ecee6735a1b37d9",
                        "language": {
                            "sourceLanguage": "ur",
                            "sourceScriptCode": "Aran",
                            "targetLanguage": "en",
                            "targetScriptCode": "Latn"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1d2492a6a31751ff1f14",
                        "language": {
                            "sourceLanguage": "ur",
                            "sourceScriptCode": "Aran",
                            "targetLanguage": "as",
                            "targetScriptCode": "Beng"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1d4092a6a31751ff1f28",
                        "language": {
                            "sourceLanguage": "ur",
                            "sourceScriptCode": "Aran",
                            "targetLanguage": "bn",
                            "targetScriptCode": "Beng"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1dc28ecee6735a1b37fa",
                        "language": {
                            "sourceLanguage": "ur",
                            "sourceScriptCode": "Aran",
                            "targetLanguage": "brx",
                            "targetScriptCode": "Deva"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1d2592a6a31751ff1f15",
                        "language": {
                            "sourceLanguage": "ur",
                            "sourceScriptCode": "Aran",
                            "targetLanguage": "gu",
                            "targetScriptCode": "Gujr"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1cd58ecee6735a1b372c",
                        "language": {
                            "sourceLanguage": "ur",
                            "sourceScriptCode": "Aran",
                            "targetLanguage": "hi",
                            "targetScriptCode": "Deva"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1d508ecee6735a1b379d",
                        "language": {
                            "sourceLanguage": "ur",
                            "sourceScriptCode": "Aran",
                            "targetLanguage": "kn",
                            "targetScriptCode": "Knda"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1dc692a6a31751ff1fa4",
                        "language": {
                            "sourceLanguage": "ur",
                            "sourceScriptCode": "Aran",
                            "targetLanguage": "ml",
                            "targetScriptCode": "Mlym"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1d8d92a6a31751ff1f6b",
                        "language": {
                            "sourceLanguage": "ur",
                            "sourceScriptCode": "Aran",
                            "targetLanguage": "mni",
                            "targetScriptCode": "Mtei"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1d8092a6a31751ff1f60",
                        "language": {
                            "sourceLanguage": "ur",
                            "sourceScriptCode": "Aran",
                            "targetLanguage": "mni",
                            "targetScriptCode": "Beng"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1d2a92a6a31751ff1f1a",
                        "language": {
                            "sourceLanguage": "ur",
                            "sourceScriptCode": "Aran",
                            "targetLanguage": "mr",
                            "targetScriptCode": "Deva"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1d038ecee6735a1b3759",
                        "language": {
                            "sourceLanguage": "ur",
                            "sourceScriptCode": "Aran",
                            "targetLanguage": "or",
                            "targetScriptCode": "Orya"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1dbb8ecee6735a1b37f2",
                        "language": {
                            "sourceLanguage": "ur",
                            "sourceScriptCode": "Aran",
                            "targetLanguage": "pa",
                            "targetScriptCode": "Guru"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1c7392a6a31751ff1e8e",
                        "language": {
                            "sourceLanguage": "ur",
                            "sourceScriptCode": "Aran",
                            "targetLanguage": "ta",
                            "targetScriptCode": "Taml"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indictrans-v2-all-gpu--t4",
                        "modelId": "641d1d0392a6a31751ff1efc",
                        "language": {
                            "sourceLanguage": "ur",
                            "sourceScriptCode": "Aran",
                            "targetLanguage": "te",
                            "targetScriptCode": "Telu"
                        }
                    }
                ]
            },
            {
                "taskType": "tts",
                "config": [
                    {
                        "serviceId": "ai4bharat/indic-tts-coqui-misc-gpu--t4",
                        "modelId": "63f7384c2ff3ab138f88c64e",
                        "language": {
                            "sourceLanguage": "en",
                            "sourceScriptCode": "Latn"
                        },
                        "supportedVoices": [
                            "male",
                            "female"
                        ]
                    },
                    {
                        "serviceId": "ai4bharat/indic-tts-coqui-indo_aryan-gpu--t4",
                        "modelId": "6348db0bfd966563f61bc2c0",
                        "language": {
                            "sourceLanguage": "as",
                            "sourceScriptCode": "Beng"
                        },
                        "supportedVoices": [
                            "male",
                            "female"
                        ]
                    },
                    {
                        "serviceId": "ai4bharat/indic-tts-coqui-misc-gpu--t4",
                        "modelId": "636e60ebff7cd87a3f7e0ff4",
                        "language": {
                            "sourceLanguage": "brx",
                            "sourceScriptCode": "Deva"
                        },
                        "supportedVoices": [
                            "female"
                        ]
                    },
                    {
                        "serviceId": "ai4bharat/indic-tts-coqui-indo_aryan-gpu--t4",
                        "modelId": "636e60ef86369150cb00432b",
                        "language": {
                            "sourceLanguage": "gu",
                            "sourceScriptCode": "Gujr"
                        },
                        "supportedVoices": [
                            "male",
                            "female"
                        ]
                    },
                    {
                        "serviceId": "ai4bharat/indic-tts-coqui-indo_aryan-gpu--t4",
                        "modelId": "633c021bfb796d5e100d4ff9",
                        "language": {
                            "sourceLanguage": "hi",
                            "sourceScriptCode": "Deva"
                        },
                        "supportedVoices": [
                            "male",
                            "female"
                        ]
                    },
                    {
                        "serviceId": "ai4bharat/indic-tts-coqui-dravidian-gpu--t4",
                        "modelId": "636e60f486369150cb00432c",
                        "language": {
                            "sourceLanguage": "kn",
                            "sourceScriptCode": "Knda"
                        },
                        "supportedVoices": [
                            "male",
                            "female"
                        ]
                    },
                    {
                        "serviceId": "ai4bharat/indic-tts-coqui-dravidian-gpu--t4",
                        "modelId": "636e60f986369150cb00432d",
                        "language": {
                            "sourceLanguage": "ml",
                            "sourceScriptCode": "Mlym"
                        },
                        "supportedVoices": [
                            "male",
                            "female"
                        ]
                    },
                    {
                        "serviceId": "ai4bharat/indic-tts-coqui-misc-gpu--t4",
                        "modelId": "648a8f561a0aff9b4805c032",
                        "language": {
                            "sourceLanguage": "mni",
                            "sourceScriptCode": "Mtei"
                        },
                        "supportedVoices": [
                            "male",
                            "female"
                        ]
                    },
                    {
                        "serviceId": "ai4bharat/indic-tts-coqui-misc-gpu--t4",
                        "modelId": "636e60feff7cd87a3f7e0ff5",
                        "language": {
                            "sourceLanguage": "mni",
                            "sourceScriptCode": "Beng"
                        },
                        "supportedVoices": [
                            "male",
                            "female"
                        ]
                    },
                    {
                        "serviceId": "ai4bharat/indic-tts-coqui-indo_aryan-gpu--t4",
                        "modelId": "636e6103ff7cd87a3f7e0ff6",
                        "language": {
                            "sourceLanguage": "mr",
                            "sourceScriptCode": "Deva"
                        },
                        "supportedVoices": [
                            "male",
                            "female"
                        ]
                    },
                    {
                        "serviceId": "ai4bharat/indic-tts-coqui-indo_aryan-gpu--t4",
                        "modelId": "6348db26fd966563f61bc2c2",
                        "language": {
                            "sourceLanguage": "or",
                            "sourceScriptCode": "Orya"
                        },
                        "supportedVoices": [
                            "male",
                            "female"
                        ]
                    },
                    {
                        "serviceId": "ai4bharat/indic-tts-coqui-indo_aryan-gpu--t4",
                        "modelId": "63905c2bff7cd87a3f7e1022",
                        "language": {
                            "sourceLanguage": "pa",
                            "sourceScriptCode": "Guru"
                        },
                        "supportedVoices": [
                            "male",
                            "female"
                        ]
                    },
                    {
                        "serviceId": "ai4bharat/indic-tts-coqui-dravidian-gpu--t4",
                        "modelId": "6348db32fd966563f61bc2c3",
                        "language": {
                            "sourceLanguage": "ta",
                            "sourceScriptCode": "Taml"
                        },
                        "supportedVoices": [
                            "male",
                            "female"
                        ]
                    },
                    {
                        "serviceId": "ai4bharat/indic-tts-coqui-dravidian-gpu--t4",
                        "modelId": "6348db37fb796d5e100d4ffe",
                        "language": {
                            "sourceLanguage": "te",
                            "sourceScriptCode": "Telu"
                        },
                        "supportedVoices": [
                            "male",
                            "female"
                        ]
                    },
                    {
                        "serviceId": "ai4bharat/indic-tts-coqui-indo_aryan-gpu--t4",
                        "modelId": "636e60e586369150cb00432a",
                        "language": {
                            "sourceLanguage": "bn",
                            "sourceScriptCode": "Beng"
                        },
                        "supportedVoices": [
                            "male",
                            "female"
                        ]
                    }
                ]
            },
            {
                "taskType": "transliteration",
                "config": [
                    {
                        "serviceId": "ai4bharat/indicxlit--cpu-fsv2",
                        "modelId": "62b0426e74a1c96b489b5441",
                        "language": {
                            "sourceLanguage": "en",
                            "targetLanguage": "as"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indicxlit--cpu-fsv2",
                        "modelId": "628c7c97d6da5111fca0f5e4",
                        "language": {
                            "sourceLanguage": "en",
                            "targetLanguage": "bn"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indicxlit--cpu-fsv2",
                        "modelId": "62b0427878d51611abf708c4",
                        "language": {
                            "sourceLanguage": "en",
                            "targetLanguage": "brx"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indicxlit--cpu-fsv2",
                        "modelId": "62b3c64fa65d5a242f462655",
                        "language": {
                            "sourceLanguage": "en",
                            "targetLanguage": "gom"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indicxlit--cpu-fsv2",
                        "modelId": "628c7c7d2abd9b3200b3003b",
                        "language": {
                            "sourceLanguage": "en",
                            "targetLanguage": "gu"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indicxlit--cpu-fsv2",
                        "modelId": "628c73ce41dcd012c08f07e3",
                        "language": {
                            "sourceLanguage": "en",
                            "targetLanguage": "hi"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indicxlit--cpu-fsv2",
                        "modelId": "628c7e662abd9b3200b3003c",
                        "language": {
                            "sourceLanguage": "en",
                            "targetLanguage": "kn"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indicxlit--cpu-fsv2",
                        "modelId": "62b0429574a1c96b489b5442",
                        "language": {
                            "sourceLanguage": "en",
                            "targetLanguage": "ks"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indicxlit--cpu-fsv2",
                        "modelId": "628cafad2abd9b3200b3003f",
                        "language": {
                            "sourceLanguage": "en",
                            "targetLanguage": "mai"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indicxlit--cpu-fsv2",
                        "modelId": "628ca83c2abd9b3200b3003e",
                        "language": {
                            "sourceLanguage": "en",
                            "targetLanguage": "ml"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indicxlit--cpu-fsv2",
                        "modelId": "62b0429f78d51611abf708c5",
                        "language": {
                            "sourceLanguage": "en",
                            "targetLanguage": "mni"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indicxlit--cpu-fsv2",
                        "modelId": "628c811dd6da5111fca0f5e5",
                        "language": {
                            "sourceLanguage": "en",
                            "targetLanguage": "mr"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indicxlit--cpu-fsv2",
                        "modelId": "62b042a878d51611abf708c6",
                        "language": {
                            "sourceLanguage": "en",
                            "targetLanguage": "ne"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indicxlit--cpu-fsv2",
                        "modelId": "62b042b878d51611abf708c7",
                        "language": {
                            "sourceLanguage": "en",
                            "targetLanguage": "or"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indicxlit--cpu-fsv2",
                        "modelId": "628ca0c52abd9b3200b3003d",
                        "language": {
                            "sourceLanguage": "en",
                            "targetLanguage": "pa"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indicxlit--cpu-fsv2",
                        "modelId": "62b042c374a1c96b489b5443",
                        "language": {
                            "sourceLanguage": "en",
                            "targetLanguage": "sa"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indicxlit--cpu-fsv2",
                        "modelId": "628cab0ed6da5111fca0f5e8",
                        "language": {
                            "sourceLanguage": "en",
                            "targetLanguage": "sd"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indicxlit--cpu-fsv2",
                        "modelId": "628cad21d6da5111fca0f5e9",
                        "language": {
                            "sourceLanguage": "en",
                            "targetLanguage": "si"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indicxlit--cpu-fsv2",
                        "modelId": "628c741941dcd012c08f07e4",
                        "language": {
                            "sourceLanguage": "en",
                            "targetLanguage": "ta"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indicxlit--cpu-fsv2",
                        "modelId": "628ca307d6da5111fca0f5e6",
                        "language": {
                            "sourceLanguage": "en",
                            "targetLanguage": "te"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indicxlit--cpu-fsv2",
                        "modelId": "628ca3e8d6da5111fca0f5e7",
                        "language": {
                            "sourceLanguage": "en",
                            "targetLanguage": "ur"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indicxlit--cpu-fsv2",
                        "modelId": "63513e599dd811234cfe86bb",
                        "language": {
                            "sourceLanguage": "as",
                            "targetLanguage": "en"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indicxlit--cpu-fsv2",
                        "modelId": "63513eae9dd811234cfe86c3",
                        "language": {
                            "sourceLanguage": "bn",
                            "targetLanguage": "en"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indicxlit--cpu-fsv2",
                        "modelId": "63513e949dd811234cfe86c1",
                        "language": {
                            "sourceLanguage": "brx",
                            "targetLanguage": "en"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indicxlit--cpu-fsv2",
                        "modelId": "63513e3d9dd811234cfe86b8",
                        "language": {
                            "sourceLanguage": "gom",
                            "targetLanguage": "en"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indicxlit--cpu-fsv2",
                        "modelId": "63513eb5610f2c0e43eeb476",
                        "language": {
                            "sourceLanguage": "gu",
                            "targetLanguage": "en"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indicxlit--cpu-fsv2",
                        "modelId": "63513d39610f2c0e43eeb46e",
                        "language": {
                            "sourceLanguage": "hi",
                            "targetLanguage": "en"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indicxlit--cpu-fsv2",
                        "modelId": "63513e7d9dd811234cfe86c0",
                        "language": {
                            "sourceLanguage": "kn",
                            "targetLanguage": "en"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indicxlit--cpu-fsv2",
                        "modelId": "63513e4e610f2c0e43eeb471",
                        "language": {
                            "sourceLanguage": "ks",
                            "targetLanguage": "en"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indicxlit--cpu-fsv2",
                        "modelId": "63513e6c9dd811234cfe86be",
                        "language": {
                            "sourceLanguage": "mai",
                            "targetLanguage": "en"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indicxlit--cpu-fsv2",
                        "modelId": "63513e549dd811234cfe86ba",
                        "language": {
                            "sourceLanguage": "ml",
                            "targetLanguage": "en"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indicxlit--cpu-fsv2",
                        "modelId": "63513e84610f2c0e43eeb473",
                        "language": {
                            "sourceLanguage": "mni",
                            "targetLanguage": "en"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indicxlit--cpu-fsv2",
                        "modelId": "63513e71610f2c0e43eeb472",
                        "language": {
                            "sourceLanguage": "mr",
                            "targetLanguage": "en"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indicxlit--cpu-fsv2",
                        "modelId": "63513e5f9dd811234cfe86bc",
                        "language": {
                            "sourceLanguage": "ne",
                            "targetLanguage": "en"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indicxlit--cpu-fsv2",
                        "modelId": "63513e779dd811234cfe86bf",
                        "language": {
                            "sourceLanguage": "or",
                            "targetLanguage": "en"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indicxlit--cpu-fsv2",
                        "modelId": "63513e659dd811234cfe86bd",
                        "language": {
                            "sourceLanguage": "pa",
                            "targetLanguage": "en"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indicxlit--cpu-fsv2",
                        "modelId": "63513e43610f2c0e43eeb470",
                        "language": {
                            "sourceLanguage": "sa",
                            "targetLanguage": "en"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indicxlit--cpu-fsv2",
                        "modelId": "63513e489dd811234cfe86b9",
                        "language": {
                            "sourceLanguage": "sd",
                            "targetLanguage": "en"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indicxlit--cpu-fsv2",
                        "modelId": "63513e9d9dd811234cfe86c2",
                        "language": {
                            "sourceLanguage": "si",
                            "targetLanguage": "en"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indicxlit--cpu-fsv2",
                        "modelId": "63513e36610f2c0e43eeb46f",
                        "language": {
                            "sourceLanguage": "ta",
                            "targetLanguage": "en"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indicxlit--cpu-fsv2",
                        "modelId": "63513ea6610f2c0e43eeb475",
                        "language": {
                            "sourceLanguage": "te",
                            "targetLanguage": "en"
                        }
                    },
                    {
                        "serviceId": "ai4bharat/indicxlit--cpu-fsv2",
                        "modelId": "63513e8c610f2c0e43eeb474",
                        "language": {
                            "sourceLanguage": "ur",
                            "targetLanguage": "en"
                        }
                    }
                ]
            }
        ],
        "feedbackUrl": "https://dhruva-api.bhashini.gov.in/services/feedback/submit",
        "pipelineInferenceAPIEndPoint": {
            "callbackUrl": "https://dhruva-api.bhashini.gov.in/services/inference/pipeline",
            "inferenceApiKey": {
                "name": "Authorization",
                "value": "z1l-1j40BTm3WrJBTmfty3jOYT0WHglffqCKNIbwqxvXx-tcfD5IWitrhmXaqj3z"
            },
            "isMultilingualEnabled": True,
            "isSyncApi": True
        },
        "pipelineInferenceSocketEndPoint": {
            "callbackUrl": "wss://dhruva-api.bhashini.gov.in",
            "inferenceApiKey": {
                "name": "Authorization",
                "value": "z1l-1j40BTm3WrJBTmfty3jOYT0WHglffqCKNIbwqxvXx-tcfD5IWitrhmXaqj3z"
            },
            "isMultilingualEnabled": True,
            "isSyncApi": True
        }
    }
    configs = model_pipeline.get("pipelineResponseConfig", [])
    for task in configs:
        if task.get("taskType") == task_type:
            for cfg in task.get("config", []):
                lang_cfg = cfg.get("language", {})
                src = lang_cfg.get("sourceLanguage")
                tgt = lang_cfg.get("targetLanguage")

                if source_language == src and (target_language is None or target_language == tgt):
                    service_id = cfg.get("serviceId")
                    break
            if service_id:
                break

    if service_id and service_id != '':
        return {
            'success': True,
            'service_id': service_id,
        }
    else:
        return {
            'success': False,
            'service_id': None,
        }